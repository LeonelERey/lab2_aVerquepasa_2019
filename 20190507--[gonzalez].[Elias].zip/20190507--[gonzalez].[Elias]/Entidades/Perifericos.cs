﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public enum EConector
    {
        PCIExpress,
        USB,
        MiniUSB,
        MicroUSB,
        PS2
    }
    public abstract class Perifericos
    {
        #region Atributos

        private EConector conector;
        private string marca;
        private string modelo;

        #endregion

        #region Constructores

        public Perifericos(string marca, string modelo, EConector conector)
        {
            this.marca = marca;
            this.modelo = modelo;
            this.conector = conector;
        }

        #endregion

        #region Propiedades



        #endregion

        #region Metodos

        public abstract string ExponerDatos();

        #endregion

        #region Operadores

        public static bool operator ==(Perifericos per1,Perifericos per2)
        {
            bool retorno = false;

            if (per1.marca == per2.marca && per2.modelo == per1.modelo)
                retorno = true;

            return retorno;
        }

        public static bool operator !=(Perifericos per1, Perifericos per2)
        {
            return !(per1 == per2);
        }

        public static explicit operator string(Perifericos per)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat($"modelo:{per.modelo}\nmarca:{per.marca}\nconector:{per.conector}\n");

            return sb.ToString();
        }
        #endregion
    }
}
