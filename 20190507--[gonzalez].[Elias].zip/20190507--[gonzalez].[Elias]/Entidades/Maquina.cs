﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Maquina
    {
        #region Atributos

        private int cantidadMaximaPerifericos;
        private string nombre;
        private List<Perifericos> perifericos;

        #endregion

        #region Constructores

        private Maquina()
        {
            perifericos = new List<Perifericos>();
            this.cantidadMaximaPerifericos = 3;
        }

        public Maquina(string nombre):this()
        {
            this.nombre=nombre;
        }

        #endregion

        #region Propiedades

        public int CapacidadMaximaPerifericos
        {
            get
            {
                return this.cantidadMaximaPerifericos;
            }
            set
            {
                if(value>0&&value<5)
                {
                    this.cantidadMaximaPerifericos = value;
                }
                else
                {
                    this.cantidadMaximaPerifericos=4;
                }
            }
        }
        public string Nombre
        {
            get
            {
                return this.nombre;
            }
            set
            {
                this.nombre = value;
            }
        }
        public string SystemInfo
        {
            get
            {
                StringBuilder sb = new StringBuilder();

                sb.AppendFormat($"nombre{this.Nombre}\n");

                foreach (Perifericos item in this.perifericos)
                {
                    //sb.AppendFormat((string)item);
                    sb.AppendFormat(item.ExponerDatos());
                }
                return sb.ToString();
            }
        }
        #endregion

        #region Metodos



        #endregion

        #region Operadores

        public static bool operator ==(Maquina ma,Perifericos per)
        {
            bool retorno = false;

            foreach (Perifericos item in ma.perifericos)
            {
                if(item==per)
                {
                    retorno = true;
                }
            }

            return retorno;
        }

        public static bool operator !=(Maquina ma, Perifericos per)
        {
            return !(ma == per);
        }

        public static string operator +(Maquina ma, Perifericos per)
        {
            StringBuilder sb = new StringBuilder();
            int aux = ma.cantidadMaximaPerifericos;

            if(ma != per && ma.perifericos.Count<aux)
            {
                ma.perifericos.Add(per);
                sb.AppendFormat("Periferico conectado\n");
            }
            else
            {
                sb.AppendFormat("no se pudo conectar el periferico\n");
            }

            return sb.ToString();
        }
        public static string operator -(Maquina ma, Perifericos per)
        {
            StringBuilder sb = new StringBuilder();

            if (ma == per )
            {
                ma.perifericos.Remove(per);
                sb.AppendFormat("Periferico desconectado\n");
            }
            else
            {
                sb.AppendFormat("no se pudo desconectar el periferico\n");
            }

            return sb.ToString();
        }
        #endregion
    }
}
