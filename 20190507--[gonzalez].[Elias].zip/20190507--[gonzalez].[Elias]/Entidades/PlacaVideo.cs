﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class PlacaVideo:Perifericos
    {
        #region Atributos

        private int ramMB;

        #endregion

        #region Constructores

        public PlacaVideo(string modelo,string marca, int ramMB):base(marca,modelo,EConector.PCIExpress)
        {
            this.ramMB = ramMB;
        }

        #endregion

        #region Propiedades



        #endregion

        #region Metodos

        public override string ExponerDatos()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat((string)this);
            sb.AppendFormat($"ramMB:{this.ramMB}\n\n");

            return sb.ToString();
        }

        #endregion

        #region Operadores



        #endregion

    }
}
