﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Teclado:Perifericos
    {
        public enum EDistribucion
        {
            Dvorak,
            QWERTY,
            QWERTZ,
            AZERTY
        }
        #region Atributos

        private EDistribucion distribucion;

        #endregion

        #region Constructores

        public Teclado(string marca,string modelo,EConector conector):base(marca,modelo,conector)
        {
            this.distribucion = EDistribucion.Dvorak;
        }
        public Teclado(string marca, string modelo, EConector conector, EDistribucion region) : base(marca, modelo, conector)
        {
            this.distribucion = region;
        }

        #endregion

        #region Propiedades



        #endregion

        #region Metodos

        public override string ExponerDatos()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat((string)this);
            sb.AppendFormat($"distribucion:{this.distribucion}\n\n");

            return sb.ToString();
        }

        #endregion

        #region Operadores

        public static bool operator ==(Teclado tec,EDistribucion dis)
        {
            bool retorno = false;

            if(tec.distribucion==dis)
            {
                retorno = true;
            }

            return retorno;
        }

        public static bool operator !=(Teclado tec, EDistribucion dis)
        {
            return !(tec == dis);
        }

        #endregion
    }
}
