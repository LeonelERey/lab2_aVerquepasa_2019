﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace Ejercico_63_lab2019
{
    public partial class Form1 : Form
    {
        delegate void Hilo(string texto);
        public Thread h1;
        public Form1()
        {
            InitializeComponent();

            h1 = new Thread(Correr);
            h1.Start();


            //timer1.Start();
            //AsignarHora();
            //Refresh();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public void AsignarHora(string texto)
        {
            if (this.lblHora.InvokeRequired)
            {
                Hilo d = new Hilo(this.AsignarHora);
                object[] objs = new object[] {texto };
                this.Invoke(d, objs);
            }
            else
            {
                this.lblHora.Text = texto;
            }
        }

        public void Correr()
        {
            do
            {

                Thread.Sleep(1000);
                string hora = DateTime.Now.ToString("dd/MM/yyyy  hh:mm:ss");
                AsignarHora(hora);

            } while (h1.IsAlive);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //AsignarHora();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            h1.Abort();
        }
    }
}
