﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Ejercicio_64
{
    public class Caja
    {
        List<string> filaPersonas;
        Thread h1 = new Thread();

        public List<string> FilaPersonas
        {
            get { return this.filaPersonas; }
        }        

        public Caja()
        {
            filaPersonas = new List<string>();
        }

        public void AtenderCliente()
        {
            StringBuilder sb = new StringBuilder();

            foreach (string item in FilaPersonas)
            {
                sb.AppendFormat($"{item}\n");
            }

            Console.Write(sb.ToString());
        }
    }
}
