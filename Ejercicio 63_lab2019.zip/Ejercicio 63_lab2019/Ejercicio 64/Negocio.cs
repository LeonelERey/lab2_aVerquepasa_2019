﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Ejercicio_64
{
    public class Negocio
    {
        Caja caja1 = new Caja();
        Caja caja2 = new Caja();
        List<string> clientes;

        public Caja Caja1
        {
            get { return this.caja1; }
        }
        public Caja Caja2
        {
            get { return this.caja2; }
        }
        public List<string> Clientes
        {
            get { return this.clientes; }
        }

        public Negocio(Caja c1,Caja c2)
        {
            clientes = new List<string>();
        }
    }
}
