using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;
using Controles;
using System.Data.SqlClient;

namespace _20190711_Final
{
  public partial class FrmAerolinea : Form
  {
    private string connectionString = _20190711_Final.Properties.Settings.Default.miBase;
    private static SqlCommand command;
    private static SqlConnection cn;
    private static SqlDataReader Ord;

    private Aeropuerto<Vuelo> aeropuerto;

    public FrmAerolinea()
    {
      InitializeComponent();

      this.aeropuerto = new Aeropuerto<Vuelo>();
    }

    private void btnAgregar_Click(object sender, EventArgs e)
    {
      int horas = (int)nudHorasDeVuelo.Value;
      Vuelo vuelo = new Vuelo(horas);
      int ejeY = this.aeropuerto + vuelo;

      this.Controls.Add(vuelo);
      vuelo.Location = new Point(0, ejeY);

      vuelo.Despegar();



      cn = new SqlConnection(connectionString);
      command = new SqlCommand();
      command.Connection = cn;

      SqlDataAdapter Dao = new SqlDataAdapter();

      command.CommandText = $"insert into dao.Bitacora (entrada,alumno) values ('{DateTime.Now}','gonzalez Elias')";

      try
      {
        cn.Open();
        command.ExecuteNonQuery();
        cn.Close();

      }
      catch (SqlException)
      {
        throw new Exception("ERROR DE SQL");
      }
      catch (Exception)
      {

        throw new Exception("ERROR DE SQL");
      }
      finally
      {
        if (cn.State == System.Data.ConnectionState.Open)
        {
          cn.Close();
        }
      }

    }

    private void FrmAerolinea_FormClosing(object sender, FormClosingEventArgs e)
    {
      this.aeropuerto.FinalizarVuelos();
    }

    private void FrmAerolinea_Load(object sender, EventArgs e)
    {

    }
  }
}
