using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using Entidades;

namespace Entidades
{
  public enum EstadoVuelo
  {
    Programado,
    Volando,
    Aterrizado
  }
  public class Avion
  {
    private int horasVuelo;
    private Thread vuelo = null;

    public Avion(int hora)
    {
      this.horasVuelo = hora;
    }

    public EstadoVuelo Estado
    {     
      get
      {
        EstadoVuelo retorno;
        if(vuelo is null)
        {
          retorno = EstadoVuelo.Programado; 
        }
        else if (vuelo.IsAlive)
        {
          retorno = EstadoVuelo.Volando;
        }
        else
        {
          retorno = EstadoVuelo.Aterrizado;
        }

        return retorno;
      }
    }

    public int HorasVuelo
    {
      get { return this.horasVuelo; }
    }

    public delegate void ReportarDeEstado(int horasTotales, int horasRestantes);
    private event ReportarDeEstado ReportarEstado;

    public void Volar()
    {
      Thread.Sleep(1000);

      int horasRestantes = this.HorasVuelo - 1;
      int porcentajeCompletado = 100;

      ReportarEstado.Invoke(this.HorasVuelo,horasRestantes);

      while (porcentajeCompletado <= 100)
      {

      }
    }

    public void Estallar()
    {
      if(this.vuelo.IsAlive)
      {
        this.vuelo.Abort();
      }
    }

  }
}
