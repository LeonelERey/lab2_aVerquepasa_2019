using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Entidades
{
  public class Aeropuerto<Vuelo>
  {
    public List<Avion> vuelos;

    public Aeropuerto()
    {

    }
    public static int operator +(Aeropuerto<Vuelo> a,Avion vuelo)
    {
      a.vuelos.Add(vuelo);

      return (a.vuelos.Count * 50);
    }

    public static explicit operator string(Aeropuerto<Vuelo> a)
    {
      int cont = 0;
      StringBuilder sb = new StringBuilder();

      foreach (Avion item in a.vuelos)
      {
        if(item.Estado == EstadoVuelo.Programado)
        {
          cont++;
        }
      }

      sb.AppendFormat($"El aeropuerto cuenta con {cont} vuelos en estado Volando");

      return sb.ToString();
    }
    public void FinalizarVuelos()
    {
      foreach (Avion item in this.vuelos)
      {
        if (item.Estado == EstadoVuelo.Programado)
        {
          item.Estallar();
        }

      }
    }
  }
}
