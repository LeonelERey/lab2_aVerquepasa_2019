using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  public class ErrorArchivoException:Exception
  {
    private string MensajeBase;

    public ErrorArchivoException() : base()
    {

    }

    public ErrorArchivoException(string mensaje) : base(mensaje)
    {

    }
  }
}
