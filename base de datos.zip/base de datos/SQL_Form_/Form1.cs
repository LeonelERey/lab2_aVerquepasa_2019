﻿using System;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using SQL_Entidades;
using System.Collections.Generic;

namespace SQL_Form_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            List<Provincias> prov = new List<Provincias>();
            SqlConnection cn = new SqlConnection(Properties.Settings.Default.CadenaASQL);
            SqlCommand com = new SqlCommand();

            com.CommandType = System.Data.CommandType.Text;
            com.Connection = cn;
            
            com.CommandText = "SELECT id, nombre FROM Provincias";

            cn.Open();

            SqlDataReader oDr = com.ExecuteReader();

            while(oDr.Read())
            {
                oDr["nombre"].ToString();
                prov.Add(new Provincias((int)(decimal)oDr["id"], oDr["nombre"].ToString()));
            }
            com.Clone();

            this.comboBox1.DataSource = prov;
        }
    }
}
