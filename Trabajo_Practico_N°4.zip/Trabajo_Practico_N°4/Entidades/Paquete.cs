﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Entidades
{
    public class Paquete : IMostrar<Paquete>
    {
        public delegate void DelegadoEstado(EEstado e);
        public static event DelegadoEstado InformaEstado;
        #region Enumerado

        public enum EEstado
        {
            Ingresando,
            EnViaje,
            Entregado
        }
        #endregion

        #region Atributos
        private string direccionEntrega;
        private EEstado estado;
        private string trackingID;

        #endregion


        #region Propiedades
        public string DireccionEntrega
        {
            get { return this.direccionEntrega; }
            set { this.direccionEntrega = value; }
        }

        public string TrackingID
        {
            get { return this.trackingID; }
            set { this.trackingID = value; }
        }

        public EEstado Estado
        {
            get { return this.estado; }
            set { this.estado = value; }
        }
        #endregion

        #region Constructores
        public Paquete(string direccionEntrega, string trackingID)
        {
            this.DireccionEntrega = direccionEntrega;
            this.TrackingID = trackingID;
        }
        #endregion

        string IMostrar<Paquete>.MostarDatos(IMostrar<Paquete> elementos)
        {
            return string.Format($"{((Paquete)elementos).TrackingID} para {((Paquete)elementos).DireccionEntrega}");
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("Datos del Paquete");
            sb.AppendLine($"Direccion de entrega: {this.DireccionEntrega}");
            sb.AppendLine($"Estado: {this.Estado}");
            sb.AppendLine($"TrackingID: {this.TrackingID}");
            return sb.ToString();
        }

        public static bool operator ==(Paquete p1, Paquete p2)
        {
            bool retorno = false;

            if (p1.TrackingID == p2.TrackingID)
            {
                retorno = true;
            }
            return retorno;
        }

        public static bool operator !=(Paquete p1, Paquete p2)
        {
            return !(p1 == p2);
        }

        public void MockCicloDeVida()
        {
            do
            {
                Thread.Sleep(4000);
                if (this.Estado == EEstado.Ingresando)
                {
                    this.Estado = EEstado.EnViaje;
                }
                else
                {
                    if(this.Estado==EEstado.EnViaje)
                    {
                        this.Estado = EEstado.Entregado;
                    }

                }

                InformaEstado(this.Estado);

            } while (this.Estado != EEstado.Entregado);

        }




    }
}
