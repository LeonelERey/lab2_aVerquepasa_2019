﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;


namespace Entidades
{
  public static  class PaqueteDAO
    {
        public delegate void ResultadoSQL(string valor);
        public static event ResultadoSQL ResultadoSqlFinal;

        public static bool Insertar(Paquete pac)
        {   
            bool retorno = false;
            string message = string.Empty;
            SqlConnection cn = new SqlConnection(Properties.Settings.Default.MiBase);
            SqlCommand command = new SqlCommand();
            SqlDataAdapter Dao = new SqlDataAdapter();

            command.CommandText = $"insert into Persona (direccionEntrega,trackingID,alumno) values ('{pac.DireccionEntrega}','{pac.TrackingID}','Joaquin Esposito')";

            try
            {
                cn.Open();
                command.ExecuteNonQuery();
                cn.Close();
                message = "Paquete guardado exitosamente.";
                retorno = true;
                ResultadoSqlFinal(message);
            }
            catch (SqlException ex)
            {
                message = $"ERROR DE SQL {ex.Message}";
                ResultadoSqlFinal(message);
            }
            catch (Exception ex)
            {
                message = $"ERROR: {ex.Message}";
                ResultadoSqlFinal(message);
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                {
                    cn.Close();
                }
            }

            return retorno;
        }
    }
}
