﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Entidades
{
    public class Correo:IMostrar<List<Paquete>>
    {
        private List<Thread> mockPaquetes;
        private List<Paquete> paquetes;

        public List<Paquete> Paquetes
        {
            get { return this.paquetes; }
            set { this.paquetes = value; }
        }
        public Correo()
        {
            this.paquetes = new List<Paquete>();
            this.mockPaquetes = new List<Thread>();
        }

        public static Correo operator +(Correo c,Paquete p)
        {
            bool flag = false;
            if(!Equals(c,null)&&!Equals(p,null))
            {
                foreach (Paquete item in c.paquetes)
                {
                    if(item==p)
                    {
                        flag = true;
                    }
                }

                if(flag)
                {
                    throw new TrackingIdRepetidoExeption("El Paquete ya se encuentra en la Lista");
                }
                else
                {
                    c.paquetes.Add(p);
                    Thread hilo = new Thread(p.MockCicloDeVida);
                    c.mockPaquetes.Add(hilo);
                    hilo.Start();

                }
            }
            return c;
        }


        public string MostarDatos(IMostrar<List<Paquete>> elementos)
        {
          return string.Format($"{((Paquete)(elementos)).TrackingID } para {((Paquete)(elementos)).DireccionEntrega} ({((Paquete)(elementos)).Estado.ToString()})");
          
        }

        public void FinEntregas()
        {
            foreach (Thread item in this.mockPaquetes)
            {
                if (item.IsAlive)
                    item.Abort();
            }
        }
    }
}
