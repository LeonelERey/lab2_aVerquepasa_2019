﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Entidades
{
    public static class GuardarString
    {
        public static bool guardar(this string texto,string archivo)
        { 
            bool apend= File.Exists(archivo);
            try
            {

                using (StreamWriter file = new StreamWriter(archivo, apend))
                {
                   
                    string[] partes = texto.Split(';');
                    foreach (string aux in partes)
                    {
                        file.WriteLine(aux);
                    }
                    return true;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
