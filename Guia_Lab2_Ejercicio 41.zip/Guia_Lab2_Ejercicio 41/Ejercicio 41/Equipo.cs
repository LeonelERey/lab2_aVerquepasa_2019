﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_41
{
    public abstract class Equipo
    {
        private string nombre;
        private DateTime fechaCreacion;

        public Equipo(string nombre, DateTime fecha)
        {
            this.FechaCreacion = fecha;
            this.Nombre = nombre;
        }

        public string Nombre
        {
            get
            {
                return this.nombre;
            }
            set
            {
                this.nombre = value;
            }
        }

        public DateTime FechaCreacion
        {
            get
            {
                return this.fechaCreacion;
            }
            set
            {
                this.fechaCreacion = value;
            }
        }

        public string Ficha()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat($"{this.Nombre} fundade el {this.FechaCreacion}");

            return sb.ToString();
        }

        public static bool operator ==(Equipo equi1,Equipo equi2)
        {
            bool retorno = false;

            if(equi1.nombre==equi2.nombre&&equi1.fechaCreacion==equi2.fechaCreacion)
            {
                retorno = true;
            }

            return retorno;
        }
        public static bool operator !=(Equipo equi1, Equipo equi2)
        {
            return !(equi1 == equi2);
        }
    }
}
