﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_41
{
    public class Torneo<T> where T : Equipo
    {
        #region Atributos
        private List<T> equipos;
        private string nombre;
        #endregion

        #region Constuctor
        public Torneo()
        {
            this.equipos = new List<T>();
        }
        #endregion

        #region Propiedades
        public List<T> Equipo
        {
            get
            {
                return this.equipos;
            }
        }

        public string Nombre
        {
            get
            {
                return this.nombre;
            }
            set
            {
                this.nombre = value;
            }
        }

        public string JugarPartido
        {
            get
            {
                StringBuilder sb = new StringBuilder();
                Random ran1 = new Random();
                int aux1 = ran1.Next(0, this.Equipo.Count);
                int aux2 = ran1.Next(0, this.Equipo.Count);

                if (!(this.Equipo is null) && this.Equipo.Count > 1)
                {
                    if (aux1 == aux2)
                    {
                        while (aux1 == aux2)
                        {
                            Random ran2 = new Random();
                            aux2 = ran2.Next(0, this.Equipo.Count);
                        }

                        sb.AppendFormat($"{this.CalcularPartida(this.Equipo.ElementAt(aux1), this.Equipo.ElementAt(aux2))}");
                    }
                }

                return sb.ToString();
            }
        }
        #endregion

        #region Metodos
        public string Mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat($"Nombre del Torneo: {this.Nombre}");
            sb.AppendFormat($"\n==============Equipos Participantes==============\n");

            foreach (T item in this.equipos)
            {
                sb.AppendFormat($"\nNombre: {item.Nombre}\nAño de Creacion:{item.FechaCreacion}\n");
            }

            return sb.ToString();
        }

        public string CalcularPartida(T equip1, T equip2)
        {
            StringBuilder sb = new StringBuilder();

            if (equip1 is EquipoFutbol && equip2 is EquipoFutbol)
            {
                Random resuE1 = new Random();
                Random resuE2 = new Random();

                sb.AppendFormat($"\n{equip1.Nombre} {resuE1.Next(0, 10)}" +
                    $" -  {equip2.Nombre} {resuE2.Next(0, 10)}");

            }
            else if (equip1 is EquipoBasquet && equip2 is EquipoBasquet)
            {
                Random resuE1 = new Random();
                Random resuE2 = new Random();

                sb.AppendFormat($"\n{equip1.Nombre} {resuE1.Next(0, 99)}" +
                    $" -  {equip2.Nombre} {resuE2.Next(0, 99)}");
            }
            else
            {
                sb.AppendFormat("ingrese dos equipos de del mismo deporte");
            }

            return sb.ToString();
        }

        #endregion

        #region Operadores
        public static bool operator ==(Torneo<T> tor, T equi)
        {
            bool retorno = false;

            foreach (T item in tor.Equipo)
            {
                if (item == equi)
                {
                    retorno = true;
                }
            }

            return retorno;
        }
        public static bool operator !=(Torneo<T> tor, T equi)
        {
            return !(tor == equi);
        }

        public static Torneo<T> operator +(Torneo<T> tor, T equi)
        {
            if (!Equals(equi, null) && !Equals(tor, null))
            {
                if (tor != equi)
                {
                    tor.equipos.Add(equi);
                }
            }

            return tor;
        }


        #endregion
    }
}
