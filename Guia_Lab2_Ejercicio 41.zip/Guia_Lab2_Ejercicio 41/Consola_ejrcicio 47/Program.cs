﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ejercicio_41;

namespace Consola_ejrcicio_47
{
    class Program
    {
        static void Main(string[] args)
        {
            Torneo<EquipoFutbol> torneo1 = new Torneo<EquipoFutbol>();
            Torneo<EquipoBasquet> torneo2 = new Torneo<EquipoBasquet>();

            EquipoFutbol independiente = new EquipoFutbol("independiente", DateTime.Today);
            EquipoFutbol chacarita = new EquipoFutbol("chacarita", DateTime.MaxValue);
            EquipoFutbol sacaChispas = new EquipoFutbol("chacarita", DateTime.MinValue);

            EquipoBasquet lackers = new EquipoBasquet("lackers",DateTime.MaxValue);
            EquipoBasquet redBull = new EquipoBasquet("redBull",DateTime.MinValue);
            EquipoBasquet michigan = new EquipoBasquet("michigan",DateTime.Now);

            torneo1 += independiente;
            torneo1 += chacarita;
            torneo1 += sacaChispas;

            torneo2 += lackers;
            torneo2 += redBull;
            torneo2 += michigan;
        }
    }
}
