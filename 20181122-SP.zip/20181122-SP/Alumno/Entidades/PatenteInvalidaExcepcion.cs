using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  public class PatenteInvalidaExcepcion : Exception
  {
    #region Methods

    public PatenteInvalidaExcepcion(string mensaje)
        : base(mensaje)
    {

    }

    public PatenteInvalidaExcepcion(string mensaje, Exception innerExeption)
        : base(mensaje, innerExeption)
    {

    }

    #endregion
  }
}
