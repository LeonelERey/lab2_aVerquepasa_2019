using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Serialization;
using System.Xml;

namespace Archivos
{
  public class Xml<T> : IArchivo<T>
  {
    public void Guardar(string archivo, T datos)
    {
      XmlSerializer ser = new XmlSerializer(typeof(T));
      XmlTextWriter writer = null;
      try
      {
        writer = new XmlTextWriter(archivo, null);
        ser.Serialize(writer, datos);
      }
      catch (Exception)
      {
        throw;
      }
      finally
      {
        writer.Close();
      }
    }

    public void Leer(string archivo, out T datos)
    {
      XmlSerializer ser = new XmlSerializer(typeof(T));
      XmlTextReader reader = null;            

      try
      {
        reader = new XmlTextReader(archivo);
        datos = (T)ser.Deserialize(reader);
      }
      catch (Exception)
      {
        datos = default(T); //Como no se pudo leer, carga con el valor nulo por defecto para el tipo de dato.
      }
      finally
      {
        reader.Close();
      }

    }
  }
}
