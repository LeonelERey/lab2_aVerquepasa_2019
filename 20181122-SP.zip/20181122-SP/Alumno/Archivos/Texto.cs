using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

using Entidades;

namespace Archivos
{
  public class Texto : IArchivo<Queue<Patente>>
  {
    #region Metodos

    public void Guardar(string archivo, Queue<Patente> datos)
    {
      StreamWriter file = null;
      
      try
      {
        file = new StreamWriter(archivo, false);
        file.Write(datos);
      }
      catch (Exception)
      {
        throw;
      }
      finally
      {
        file.Close();
      }
    }

    public void Leer(string archivo, out Queue<Patente> datos)
    {
      StreamReader file = null;
      try
      {
        file = new StreamReader(archivo);
        foreach (Patente item in datos)
        {

        }
        datos = file.ReadToEnd();
      }
      catch (Exception)
      {
        datos = null;
      }
      finally
      {
        file.Close();
      }
    }

    #endregion
  }
}
