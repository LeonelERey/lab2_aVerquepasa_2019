using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using Entidades;

namespace Archivos
{
  public class Sql : IArchivo<Queue<Patente>>
  {
    private static SqlCommand comando;
    private static SqlConnection conexion;
    private static SqlDataReader reader;

    public Sql()
    {
      conexion = new SqlConnection(Properties.Settings.Default.miBase);
      comando = new SqlCommand();
      comando.CommandType = System.Data.CommandType.Text;
      comando.Connection = conexion;
    }
    public void Guardar(string tabla, Queue<Patente> datos)
    {    

      try
      {
        foreach (Patente item in datos)
        {
          comando.CommandText = String.Format("INSERT INTO {0} (patente,tipo) VALUES('{1}','{2}')", tabla, item.CodigoPatente, item.TipoCodigo);
          conexion.Open();
          comando.ExecuteNonQuery();
        }

        conexion.Close();
      }
      catch (Exception e)
      {
        throw e;
      }
      finally
      {
        if (conexion.State == System.Data.ConnectionState.Open)
        {
          conexion.Close();
        }
      }
    }

    public void Leer(string tabla, out Queue<Patente> datos)
    {
      datos = new Queue<Patente>();
      Patente p = null;
      try
      {
        comando.CommandText = String.Format($"select * from {tabla}");
        conexion.Open();
        reader = comando.ExecuteReader();
        while (reader.Read())
        {
          p = PatenteStringExtension.ValidarPatente(reader.GetString(1));
          datos.Enqueue(p);
        }

        comando.Clone();
      }
      catch (PatenteInvalidaExcepcion Pe)
      {
        throw Pe;
      }
      catch (Exception e)
      {
        throw e;
      }
      finally
      {
        if (conexion.State == System.Data.ConnectionState.Open)
        {
          conexion.Close();
        }
      }
    }
  }
}
