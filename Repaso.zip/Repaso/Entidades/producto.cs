﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Producto
    {
        private string codigodeBarra;
        private string marca;
        private float precio;

        public Producto(string marca, string codigo, float precio)
        {
            this.codigodeBarra = codigo;
            this.marca = marca;
            this.precio = precio;
        }

        public string GetMarca()
        {
            return this.marca;
        }
        public float GetPrecio()
        {
            return this.precio;
        }
        public string MostrarProducto(Producto p)
        {
            StringBuilder producto = new StringBuilder();

            producto.AppendFormat($"{p.marca}\n{p.codigodeBarra}\n{p.precio}");

            return producto.ToString();
        }
        public static explicit operator string(Producto p)
        {
            return p.codigodeBarra;
        }
        public static bool operator ==(Producto p1, Producto p2)
        {
            bool retorno = false;
            if (Equals(p1, null) && Equals(p2, null))
            {
                if (p1.codigodeBarra == p2.codigodeBarra && p1.marca == p2.marca)
                {
                    retorno = true;
                }

            }

            return retorno;
        }
        public static bool operator !=(Producto p1, Producto p2)
        {
            return !(p1 == p2);
        }
        public static bool operator ==(Producto p1, string marca)
        {
            bool retorno = false;

            if (p1.codigodeBarra == marca)
            {
                retorno = true;
            }

            return retorno;
        }
        public static bool operator !=(Producto p1, string marca)
        {
            return !(p1 == marca);
        }
    }
}
