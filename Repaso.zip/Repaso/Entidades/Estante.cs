﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Estante
    {
        private Producto[] producto;
        private int ubicacionestante;

        private Estante(int capacidad)
        {
            this.producto = new Producto[capacidad];
        }
        public Estante(int capacidad, int ubicacion) : this(capacidad)
        {
            this.ubicacionestante = ubicacion;
        }
        public Producto[] GetProductos()
        {
            return this.producto;
        }
        public static bool operator +(Estante e, Producto p)
        {
            bool retorno = false;
            if (e != p)
            {
                for (int i = 0; i < e.producto.Length; i++)
                {
                    if (e.producto[i] != p && Equals(e.producto[i], null))
                    {
                        retorno = true;
                        e.producto[i] = p;
                    }
                }                
            }
            return retorno;
        }
        public static Estante operator -(Estante e, Producto p)
        {
            if (e == p)
            {
                for (int i = 0; i < e.producto.Length; i++)
                {
                    if(e.producto[i]==p)
                    {
                        e.producto[i] = null;
                    }
                }
            }
            return e;
        }
        public static bool operator ==(Estante e, Producto p)
        {
            bool retorno = false;

            for (int i = 0; i < e.producto.Length; i++)
            {
                if (e.producto[i] == p)
                {
                    retorno = true;
                }
            }
            return retorno;
        }
        public static bool operator !=(Estante e, Producto p)
        {
            return !(e == p);
        }
        public static string MostrarEstante(Estante e)
        {
            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < e.producto.Length; i++)
            {
                sb.AppendFormat($"{e.producto[i].MostrarProducto(e.producto[i])}\n{e.ubicacionestante}");
            }

            return sb.ToString();
            
        }
    }

}
