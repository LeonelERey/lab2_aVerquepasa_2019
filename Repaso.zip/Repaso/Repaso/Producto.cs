﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* MostrarProducto -> Public
 * _marca: string -> EMarcaProducto
 * _codigoDeBarra: string
 * _precio: float
 * Producto (String, String, float)
 * 
 * Estante -> Atributo ubicacion: int -> public Estante (int, int)
 */
namespace Repaso
{
    public class Producto
    {
        //Atributos
        protected string _marca = "";
        protected string _codigoDeBarra = "";
        protected float _precio = 0;
    
        //Metodos
        public string GetMarca()
        {
            return this._marca;
        }
        
        public float GetPrecio()
        {
            return this._precio;
        }
        
        public string MostrarProducto()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Marca: " + this._marca);
            sb.AppendLine("Codigo de Barra: " + this._codigoDeBarra);
            sb.AppendLine("Precio: " + this._precio.ToString());
            
            return sb.ToString();
        }

        public bool Igualdad(Producto _p1, Producto _p2)
        {
            if ((_p1._marca != _p2._marca) && (_p1._codigoDeBarra != _p2._codigoDeBarra))
                return false;

            return true;
        }

        public bool Igualdad(Producto _p1, string _emp1)
        {
            if (_p1._marca != _emp1)
                return false;

            return true;
        }

        public static explicit operator string (Producto _p1)
        {
            return _p1._codigoDeBarra;
        }

        //Constructor
        public Producto(string marca, string codigo, float precio)
        {
            this._marca = marca;
            this._codigoDeBarra = codigo;
            this._precio = precio;
        }

    }


}
