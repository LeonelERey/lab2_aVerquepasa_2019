﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace Repaso
{
    
    class Estante
    {
        
        //Atributos
        protected int _cantidad = 0;
        protected Producto[] arrayProducto;
        protected int _ubicacion = 0;
        

        // Constructor
        public Estante(int c1, int u1) 
        {
            this._cantidad = 
            
        }
        
        private Estante(int cMax)
        {
            this.arrayProducto = new Producto[cMax];
        }

    }
}
