﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repaso
{
    class Program
    {
        static void Main(string[] args)
        {
             
            Producto p1 = new Producto("AAA", "A123D", 12);
            Producto p2 = new Producto("BBB", "A563U", 61);
            Producto p3 = new Producto("AAA", "A123D", 15);

            if (p1.Igualdad(p1, p3))
            {
                Console.WriteLine("Los productos son iguales.\n\n");
            }
            else
            {
                Console.WriteLine("Los productos NO son iguales.\n\n");
            }

            if (p1.Igualdad(p1, "ABD"))
            {
                Console.WriteLine("Los productos son iguales.\n\n");
            }
            else
            {
                Console.WriteLine("Los productos NO son iguales.\n\n");
            }

            Console.WriteLine("Codigo de barra p1: " + ((string)p1));

            Console.WriteLine(p1.MostrarProducto());
            Console.WriteLine(p2.MostrarProducto());
            Console.WriteLine(p3.MostrarProducto());

            Console.ReadKey();
        }
    }
}
