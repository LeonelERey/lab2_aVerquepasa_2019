using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;

namespace EntitiesDAO
{
  interface IData<T>
  {
    /*void Guardar(Emisor emisor, T dato);
    void leer(string archivo, out T dato);*/

  }
}
