﻿namespace Persistencia
{
    public class WhatsappTexto
    {
        private readonly string path;

        /// <summary>
        /// Asignar valor al path
        /// </summary>
        public WhatsappTexto()
        {
        }
    }
}
