﻿namespace Persistencia
{
    public class WhatsappXml
    {
        private readonly string path;

        /// <summary>
        /// Le asigna un valor al path.
        /// </summary>
        public WhatsappXml()
        {
        }
    }
}
