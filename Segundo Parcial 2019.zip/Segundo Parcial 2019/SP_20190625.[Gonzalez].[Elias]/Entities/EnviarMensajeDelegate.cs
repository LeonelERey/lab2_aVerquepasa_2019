using System;

namespace Entities
{
  /*public delegate void EnviarMensajeDelegado(Emisor mensaje);*/// Hacer el delegado 
}
