using System;

namespace Entities.Exceptions
{
  public class EmisorException : Exception
  {
    
  }
}
