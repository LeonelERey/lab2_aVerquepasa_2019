using System;

namespace Entities.Exceptions
{
  public class WhatsappException:Exception
  {
    public override string Message
    {
      get
      {
        return "el numero esta fuera de rango";
      }

    }
    public string mensajeNumero()
    {
      return "el numero esta fuera de rango";
    }
    public string mensajeNumeroNoCargado()
    {
      return "el numero no fue cargado";
    }

  }
}
