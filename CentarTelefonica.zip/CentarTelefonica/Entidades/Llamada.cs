﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Llamada
    {
        #region Nested TYpes
        public enum TipoLlamada
        {
            Local,
            Provincial,
            Todas
        }
        #endregion

        #region Fields
        protected float duracion;
        protected string nroDestino;
        protected string nroOrigen;
        #endregion

        #region Propieties
        public float Duracion
        {
            get
            {
                return this.duracion;
            }
        }
        public string NroDestino
        {
            get
            {
                return this.nroDestino;
            }
        }
        public string NroOrigen
        {
            get
            {
                return this.nroOrigen;
            }
        }
        #endregion

        #region Methods
        public Llamada(float duracion,string nroDestino, string nroOrigen)
        {
            this.duracion = duracion;
            this.nroDestino = nroDestino;
            this.nroOrigen = nroOrigen;
        }
        public int OrdenarPorDuracion(Llamada llamada1,Llamada llamada2)
        {
            int retorno=0;

            if(llamada1.duracion>llamada2.duracion)
            {
                retorno = 1;
            }
            else
            {
                if(llamada2.duracion > llamada1.duracion)
                {
                    retorno = -1;
                }
            }

            return retorno;
        }
        public string Mostar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat($"Duracion: {this.duracion}\nNumero Destino: {this.nroDestino}\nNumero Origen: {this.nroOrigen}");

            return sb.ToString();
        }
        #endregion
    }
}
