﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Centralita
    {
        #region Fields
        private List<Llamada> listaDeLlamadas;
        protected string razonSocial;
        #endregion

        #region Propieties
        public float GanaciasPorLocal
        {
            get
            {
                return this.CalcularGanancia(Llamada.TipoLlamada.Local);
            }
        }

        public float GanaciasPorProvincial
        {
            get
            {
                return this.CalcularGanancia(Llamada.TipoLlamada.Provincial);
            }
        }

        public float GanaciasPorTodas
        {
            get
            {
                return this.CalcularGanancia(Llamada.TipoLlamada.Todas);
            }
        }
        #endregion

        #region Methods
        public Centralita()
        {
            this.listaDeLlamadas = new List<Llamada>();
        }

        public Centralita(string nombreEmpresa) : this()
        {
            this.razonSocial = nombreEmpresa;
        }

        private float CalcularGanancia(Llamada.TipoLlamada tipo)
        {
            float retorno = 0;
            float auxLocal = 0;
            float auxProvincial = 0;
            float auxTodas = 0;

            foreach (Llamada item in listaDeLlamadas)
            {
                if (item is Local)
                {
                    auxLocal += ((Local)item).CostoLlamada;
                    auxTodas += ((Local)item).CostoLlamada;
                }
                else
                {
                    if (item is Provincial)
                    {
                        auxProvincial += ((Provincial)item).CostoLlamada;
                        auxTodas += ((Provincial)item).CostoLlamada;
                    }
                }

            }

            if (tipo == Llamada.TipoLlamada.Local)
            {
                retorno = auxLocal;
            }
            else
            {
                if (tipo == Llamada.TipoLlamada.Provincial)
                {
                    retorno = auxProvincial;
                }
                else
                {
                    retorno = auxTodas;
                }
            }

            return retorno;
        }

        public string mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat($"Rason Social: {this.razonSocial}\nGanancia Local: {this.GanaciasPorLocal}\nGanancia Provincial: {this.GanaciasPorProvincial}\nGanancia Total: {this.GanaciasPorTodas}");
            foreach (Llamada item in listaDeLlamadas)
            {

                sb.AppendFormat($"\n\n====================================================\n\n");

                sb.AppendFormat($"{item.Mostar()}");
            }

            return sb.ToString();
        }
        #endregion

    }
}
