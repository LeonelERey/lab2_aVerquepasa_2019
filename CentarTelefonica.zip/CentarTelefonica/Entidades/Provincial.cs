﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Provincial : Llamada
    {
        #region Nested Type
        public enum Franja
        {
            Franja_1,
            Franja_2,
            Franja_3
        }
        #endregion

        #region Fields
        protected Franja franjaHoraria;
        #endregion

        #region Propieties
        public float CostoLlamada
        {
            get
            {
                return this.CalcularCosto();
            }

        }
        #endregion

        #region Methods
        public Provincial(string origen, Franja miFranja, float duracion,string destino):base(duracion,destino,origen)
        {
            this.franjaHoraria = miFranja;
        }
        public Provincial(Franja miFranja,Llamada llamada):this(llamada.NroOrigen, miFranja, llamada.Duracion, llamada.NroDestino)
        {

        }
        public string Mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat($"{base.Mostar()}\nFranja: {franjaHoraria}");

            return sb.ToString();
        }
        private float CalcularCosto()
        {
            float retorno=base.Duracion * 0.66f;

            if (franjaHoraria==Franja.Franja_1)
            {
                retorno = base.Duracion * 0.99f;
            }
            else
            {
                retorno = base.Duracion * 1.25f;
            }

            return retorno;
            
        }
        #endregion
    }
}
