﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Local : Llamada
    {
        #region Fields
        protected float costo;
        #endregion

        #region Propieties
        public float CostoLlamada
        {
            get
            {
                return this.CalcularCosto();
            }
        }
        #endregion

        #region Methods
        public Local(string origen,float duracion,string destino,float costo):base(duracion,destino,origen)
        {
            this.costo = costo;
        }

        public Local(Llamada llamada,float costo):this(llamada.NroOrigen,llamada.Duracion,llamada.NroDestino,costo)
        {

        }

        public string Mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat($"{base.Mostar()}\nCosto: {costo}");

            return sb.ToString();
            
        }
        private float CalcularCosto()
        {
            float retorno;

            retorno = base.duracion * costo;

            return retorno;
        }
        #endregion
    }
}
