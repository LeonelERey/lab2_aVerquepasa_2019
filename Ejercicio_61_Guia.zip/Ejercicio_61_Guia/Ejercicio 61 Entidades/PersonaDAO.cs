﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;

namespace Ejercicio_61_Entidades
{
    public class PersonaDAO
    {
        List<Persona> personas = new List<Persona>();

        public string Guardar(Persona per)
        {
            string messege = string.Empty;
            SqlConnection connection = new SqlConnection(Properties.Settings.Default.ListaPer);
            SqlCommand command = new SqlCommand();

            command.CommandType = System.Data.CommandType.Text;
            command.Connection = connection;

            command.CommandText = ($"insert into Persona (Nombre,Apellido) values ({per.Nombre},{per.Apellido});");

            try
            {
                connection.Open();

                command.ExecuteNonQuery();

                connection.Close();

                messege = "Persona Agregada Exitosamente";
            }
            catch (SqlException ex)
            {
                messege = $"ERROR DE SQL {ex.Message}";
            }
            catch (Exception ex)
            {
                messege = $"ERROR: {ex.Message}";
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }

            return messege;
        }

        public List<Persona> leer()
        {
            SqlConnection connection = new SqlConnection(Properties.Settings.Default.ListaPer);
            SqlCommand command = new SqlCommand();

            command.CommandType = System.Data.CommandType.Text;
            command.Connection = connection;

            command.CommandText = ($"SELECT id, nombre, apellido FROM Persona;");

            try
            {
                connection.Open();

                SqlDataReader oDr = command.ExecuteReader();

                while (oDr.Read())
                {
                    //oDr["nombre"].ToString();
                    personas.Add(new Persona((string)oDr["nombre"], (string)oDr["Apellido"], (int)(decimal)oDr["id"]));
                }
                command.Clone();
            }
            catch (SqlException)
            {
                throw new Exception("Fallo en la conexion de base de datos.");
            }
            catch (Exception)
            {
                throw new Exception("comuniquese con algun administrador.");
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }

            return personas;
        }

        public Persona LeerPorId(int id)
        {
            Persona per;
            SqlConnection connection = new SqlConnection(Properties.Settings.Default.ListaPer);
            SqlCommand command = new SqlCommand();

            command.CommandType = System.Data.CommandType.Text;
            command.Connection = connection;

            command.CommandText = ($"SELECT id=1 FROM Persona;");

            try
            {
                connection.Open();

                SqlDataReader oDr = command.ExecuteReader();

                per = new Persona((string)oDr["nombre"], (string)oDr["Apellido"], (int)(decimal)oDr["id"]);

                command.Clone();
            }
            catch (SqlException)
            {
                throw new Exception("Fallo en la conexion de base de datos.");
            }
            catch (Exception)
            {
                throw new Exception("La id pedidaq no existe.");
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }

            return per;
        }

        public string Modificar (Persona per)
        {
            SqlConnection connection = new SqlConnection(Properties.Settings.Default.ListaPer);
            SqlCommand command = new SqlCommand();
            string messege = string.Empty;

            command.CommandType = System.Data.CommandType.Text;
            command.Connection = connection;

            command.CommandText = ($"update Persona set Nombre = {per.Nombre},Apellido = {per.Apellido} where id = {per.Id}");

            try
            {
                connection.Open();

                SqlDataReader oDr = command.ExecuteReader();

                command.Clone();

                messege = "Persona Modificada Correctamente.";
            }
            catch (SqlException ex)
            {
                messege = $"ERROR DE SQL {ex.Message}";
            }
            catch (Exception ex)
            {
                messege = $"ERROR: {ex.Message}";
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return messege;
        }

        public string Eliminar(Persona per)
        {
            SqlConnection connection = new SqlConnection(Properties.Settings.Default.ListaPer);
            SqlCommand command = new SqlCommand();
            string messege = string.Empty;

            command.CommandType = System.Data.CommandType.Text;
            command.Connection = connection;

            command.CommandText = ($"delete from Persona where id = {per.Id}");

            try
            {
                connection.Open();

                SqlDataReader oDr = command.ExecuteReader();

                command.Clone();

                messege = "Persona Eliminada Correctamente.";
            }
            catch (SqlException ex)
            {
                messege = $"ERROR DE SQL {ex.Message}";
            }
            catch (Exception ex)
            {
                messege = $"ERROR: {ex.Message}";
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return messege;
        }
    }
}
