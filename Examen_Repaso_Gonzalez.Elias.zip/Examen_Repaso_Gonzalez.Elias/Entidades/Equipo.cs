﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Equipo
    {
        #region Atributos
        private const int cantidadMaximajugadores = 6;
        private DirectorTecnico directorTenico;
        private List<Jugador> jugadores;
        private string nombre;
        #endregion

        #region Propiedades
        public DirectorTecnico DirectorTecnico
        {
            set
            {
                if (!Equals(value, null))
                {
                    if (value.ValidarAptitud())
                    {
                        this.directorTenico = value;
                    }
                }
            }
        }
        public string Nombre
        {
            get
            {
                return this.nombre;
            }
        }
        #endregion

        #region Constructores
        private Equipo()
        {
            jugadores = new List<Jugador>();
        }

        public Equipo(string nombre) : this()
        {
            this.nombre = nombre;
        }
        #endregion

        #region Metodos
        public static bool ValidarEquipo(Equipo equip)
        {
            bool retorno = false;
            int arqAux = 0;
            int defAux = 0;
            int medAux = 0;
            int delAux = 0;
            Posicion pos;


            if (!Equals(equip.directorTenico, null))
            {
                foreach (Jugador item in equip.jugadores)
                {
                    pos = item.Posicion;

                    switch (pos)
                    {
                        case Posicion.Arquero:
                            arqAux++;
                            break;
                        case Posicion.Defensor:
                            defAux = 1;
                            break;
                        case Posicion.Central:
                            medAux = 1;
                            break;
                        case Posicion.Delantero:
                            delAux = 1;
                            break;
                    }
                }
                if (arqAux == 1 && defAux == 1 && medAux == 1 && delAux == 1)
                {
                    if (equip.jugadores.Count == Equipo.cantidadMaximajugadores)
                    {
                        retorno = true;
                    }
                }

            }

            return retorno;
        }
        #endregion

        #region Operadores
        public static explicit operator string(Equipo equip)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("=======Equipo=======\n\n");
            sb.AppendFormat($"Nombre: {equip.Nombre}\n\n");
            sb.AppendFormat("=======DT=======\n\n");
            if (!Equals(equip.directorTenico, null))
            {
                sb.AppendFormat(equip.directorTenico.Mostrar());
                sb.AppendFormat("\n");
            }
            else
            {
                sb.AppendFormat("Sin DT asignado\n\n");
            }
            sb.AppendFormat("=======Jugadores=======\n\n");
            foreach (Jugador item in equip.jugadores)
            {
                sb.AppendFormat(item.Mostrar());
                sb.AppendFormat("\n");
            }

            return sb.ToString();
        }

        public static bool operator ==(Equipo equip, Jugador jug)
        {
            bool retorno = false;

            foreach (Jugador item in equip.jugadores)
            {
                if (item == jug)
                {
                    retorno = true;
                }
            }

            return retorno;
        }

        public static bool operator !=(Equipo equip, Jugador jug)
        {
            return !(equip == jug);
        }

        public static Equipo operator +(Equipo equip, Jugador jug)
        {
            if (equip.jugadores.Count < Equipo.cantidadMaximajugadores)
            {
                if (equip != jug)
                {
                    if (jug.ValidarAptitud())
                    {
                        equip.jugadores.Add(jug);
                    }
                }
            }

            return equip;
        }
        #endregion
    }
}
