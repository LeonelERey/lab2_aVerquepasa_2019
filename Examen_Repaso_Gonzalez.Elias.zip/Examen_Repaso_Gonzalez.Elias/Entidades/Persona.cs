﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public enum Posicion
    {
        Arquero,
        Defensor,
        Central,
        Delantero
    }
    public abstract class Persona
    {
        #region Atributos
        private string apellido;
        private int dni;
        private int edad;
        private string nombre;
        #endregion

        #region Propiedades
        public string Apellido
        {
            get
            {
                return this.apellido;
            }
        }
        public string Nombre
        {
            get
            {
                return this.nombre;
            }
        }
        public int Dni
        {
            get
            {
                return this.dni;
            }
        }
        public int Edad
        {
            get
            {
                return this.edad;
            }
        }
        #endregion

        #region Constructores
        public Persona(string nombre,string apellido,int edad,int dni)
        {
            this.apellido = apellido;
            this.nombre = nombre;
            this.edad = edad;
            this.dni = dni;
        }
        #endregion

        #region Metodos
        public virtual string Mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat($"Apellido: {this.Apellido}\nNombre: {this.Nombre}\nDNI: {this.Dni}\nEdad: {this.Edad}\n");

            return sb.ToString();
        }
        public abstract bool ValidarAptitud();
        #endregion
    }
}
