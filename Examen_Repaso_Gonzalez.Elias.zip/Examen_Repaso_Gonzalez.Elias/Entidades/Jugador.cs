﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Jugador:Persona
    {
        #region Atributos
        private float altura;
        private float peso;
        private Posicion posicion;
        #endregion

        #region Propiedades
        public float Altura
        {
            get
            {
                return this.altura;
            }
        }
        public float Peso
        {
            get
            {
                return this.peso;
            }
        }
        public Posicion Posicion
        {
            get
            {
                return this.posicion;
            }
        }
        #endregion

        #region Constructores
        public Jugador(string nombre,string apellido,int edad,int dni,float peso,float altura,Posicion posicion):base(nombre,apellido,edad,dni)
        {
            this.altura = altura;
            this.peso = peso;
            this.posicion = posicion;
        }
        #endregion

        #region Metodos
        public override string Mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat(base.Mostrar());
            sb.AppendFormat($"Altura: {this.Altura}\nPeso: {this.Peso}\n Posicion: {this.Posicion}\n");

            return base.Mostrar();
        }
        public bool ValidarEstadoFisico()
        {
            float IMC;
            bool retorno = false;

            IMC = this.Peso / (float)Math.Pow(this.Altura,2); 

            if(IMC >= 18.5 && IMC <= 25)
            {
                retorno = true;
            }

            return retorno;
        }
        public override bool ValidarAptitud()
        {
            bool retorno = false;
            bool estado = this.ValidarEstadoFisico();

            if(this.Edad < 41 && estado == true)
            {
                retorno = true;
            }

            return retorno;
        }
        #endregion

    }
}
