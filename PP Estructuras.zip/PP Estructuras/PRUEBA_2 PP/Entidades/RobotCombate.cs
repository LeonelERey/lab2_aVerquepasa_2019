﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class RobotCombate:Robot
    {

        #region Atributos

        private int caballosDeFuerza;
        private bool lucho;

        #endregion

        #region Constructores
        public RobotCombate():base()
        {
            this.lucho = false;
        }
        public RobotCombate(int energia,string origen):base(energia,origen)
        {
            this.lucho = false;
            this.caballosDeFuerza = 10;
        }
        public RobotCombate(int energia, string origen,int caballosDeFuerza) : this(energia, origen)
        {
            this.caballosDeFuerza = caballosDeFuerza;
        }
        #endregion

        #region Propiedades

        public int CaballoDefuerza
        {
            get
            {
                return this.caballosDeFuerza;
            }
        }
        public bool Lucho
        {
            get
            {
                return this.lucho;
            }
        }

        #endregion

        #region Metodos

        public override string ServirHumanidad()
        {
            StringBuilder sb = new StringBuilder();

            if(this.energia>0)
            {
                this.energia -= 1;

                sb.AppendFormat($"Robot De combate {this.Codigo} - Disparando misiles...");
            }
            else
            {
                sb.AppendFormat($"Robot De combate {this.Codigo} - Sin energía");
            }

            return sb.ToString();
        }

        #endregion

        #region Operadores

        #endregion

    }
}
