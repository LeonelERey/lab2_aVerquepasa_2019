﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Robot
    {
        #region Atributos

        private int codigo;
        private static int contador;
        protected int energia;
        protected string origen;
        protected static int capasidadEnergia;

        #endregion

        #region Constructores

        static Robot()
        {
            capasidadEnergia = 50;
            contador = 0;
        }
        protected Robot()
        {
            this.origen = "coreano";
            this.energia = 10;
            contador++;
            this.codigo = contador;
        }
        public Robot(int energia, string origen):this()
        {
            this.energia = energia;
            this.origen = origen;
        }

        #endregion

        #region Propiedades

        public int CapacidadEnergia
        {
            get
            {
                return capasidadEnergia;
            }
        }
        public int Codigo
        {
            get
            {
                return this.codigo;
            }
        }
        public int Energia
        {
            get
            {
                return this.energia;
            }
        }
        #endregion

        #region Metodos
        public virtual bool CargarEnergia(int energia)
        {
            bool retorno = false;

            if(energia < capasidadEnergia || energia > 0)
            {
                this.energia = energia;
                retorno = true;
            }

            return retorno;
        }
        public abstract string ServirHumanidad();
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"Capacidad: {CapacidadEnergia}\nCodigo: {this.Codigo}\nContador: {contador}\nEnergia: {this.Energia}\nOrigen: {this.origen}");

            return sb.ToString();
        }
        #endregion

        #region Operadores

        public static bool operator ==(Robot rob1,Robot rob2)
        {
            bool retorno = false;

            if(!(rob1 is null) && !(rob2 is null) && rob1.codigo == rob2.codigo)
            {
                retorno = true;
            }

            return retorno;
        }
        public static bool operator !=(Robot rob1, Robot rob2)
        {
            return !(rob1 == rob2);
        }
        #endregion
    }
}
