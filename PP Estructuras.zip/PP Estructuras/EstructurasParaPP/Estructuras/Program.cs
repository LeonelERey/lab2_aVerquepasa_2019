﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Estructuras
{
    class Program
    {
        #region Atributos



        #endregion

        #region Constructores



        #endregion

        #region Propiedades



        #endregion

        #region Metodos



        #endregion

        #region Operadores


    
        #endregion
    }

}


