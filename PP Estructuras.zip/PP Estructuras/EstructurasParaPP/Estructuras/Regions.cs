﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Estructuras
{
    class Regions
    {
        #region 

        #endregion

        #region Constructores
        /*
        static XXXXX()
        {

        }
        private XXXXX()
        {

        }
        public XXXXX()
        {

        }
        */
        #endregion

        #region Propiedades
        /*
        public Tipo Atributo
        {
            get
            {
                return ;
            }
            set
            {
                this.atributo = value;
            }
        }
        */
        #endregion

        #region Metodos
        /*
        public virtual string Mostrar()
        {
            StringBuilder sb = new StringBuilder();
            


            return sb.ToString();
        }
        */
        #endregion

        #region Operadores
        /*
        
        /// <summary>
        /// compara dos elementos.
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static bool operator ==(object,object)
        {
            bool retorno = false;



            return retorno;
        }

        public static bool operator !=(object, object)
        {
            return !(X==Y);
        }
        
        /// <summary>
        /// Metodo que sobrecarga el operador +
        /// </summary>
        /// <param name="">Dato de tipo Numero</param>
        /// <param name="">Dato de tipo Numero</param>
        /// <returns>Resultado de la operacion</returns>
        public static bool operator +(object, object)
        {

        }
        
        /// <summary>
        /// Metodo que sobrecarga el operador -
        /// </summary>
        /// <param name="num1">Dato de tipo Numero</param>
        /// <param name="num2">Dato de tipo Numero</param>
        /// <returns>Resultado de la operacion</returns
        public static bool operator -(object, object)
        {

        }
        
        /// <summary>
        /// Arma un texto a imprimir.
        /// </summary>
        public static explicit operator string()
        {
            StringBuilder sb = new StringBuilder();
            
            foreach (var item in collection)
            {

            }

            return sb.ToString();
        }
        
        /// <summary>
        /// Valida que la la cadena recibida contenga caracteres numericos
        /// </summary>
        /// <param name="strNumero">Cadena a validar</param>
        /// <returns>Retorna el valor de ser posible o 0 en caso contrario</returns>
        public static double ValidarNumero(string strNumero)
        {
            double retorno;

            if (!double.TryParse(strNumero, out retorno))
            {
                retorno = 0;
            }

            return retorno;
        }

        */
        #endregion
    }
}
