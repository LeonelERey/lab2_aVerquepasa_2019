﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Moto:Vehiculo
    {
        #region Atributos

        private int cilindrada;
        private static short ruedasMoto;
        private static int valorHora;

        #endregion

        #region Constructores 

        static Moto()
        {
            valorHora = 30;
            ruedasMoto = 2;
        }
        public Moto(string patente, int cilindrada):base(patente)
        {
            
        }
        public Moto(string patente, int cilindrada,short ruedas):this(patente,cilindrada)
        {
            ruedasMoto = ruedas;
        }
        public Moto(string patente, int cilindrada, short ruedas,int valor) : this(patente, cilindrada, ruedas)
        {
            valorHora = valor;
        }

        #endregion

        #region Metodos
        public override bool Equals(object obj)
        {
            bool retorno = false;

            if (obj is Moto)
            {
                retorno = true;
            }

            return retorno;
        }
        public override string ConsultarDatos()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat($"{base.ImprimirTicket()}");
            sb.AppendFormat($"Cilindradas: {this.cilindrada}\nRuedas: {ruedasMoto}\nValor Hora: {valorHora}\n\n");

            return sb.ToString();
        }
        public override string ImprimirTicket()
        {
            
            StringBuilder sb = new StringBuilder();

            TimeSpan aux = ingreso - DateTime.Now;

            sb.AppendFormat(this.ConsultarDatos());
            sb.AppendFormat($"Costo estadia: {(DateTime.Now - this.ingreso).Hours * valorHora}\n");

            return sb.ToString();
        }

        #endregion

    }
}
