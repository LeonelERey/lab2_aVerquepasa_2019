﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Estacionamiento
    {
        #region Atributo

        private int espacioDisponible;
        private string nombre;
        private List<Vehiculo> vehiculos;

        #endregion

        #region Constructores 

        private Estacionamiento()
        {
            vehiculos = new List<Vehiculo>();
        }
        public Estacionamiento(string nombre, int espacioDisponible) : this()
        {
            this.nombre = nombre;
            this.espacioDisponible = espacioDisponible;
        }
        #endregion

        #region Propiedades


        #endregion

        #region Metodos

        #endregion

        #region Operadores

        public static explicit operator string(Estacionamiento esta)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("\n==================Estacionamiento==================\n\n");
            sb.AppendFormat($"Nombre: {esta.nombre}\nEspacio Disponible: {esta.espacioDisponible}");

            sb.AppendFormat("\n==================Vehiculos==================\n\n");

            foreach (Vehiculo item in esta.vehiculos)
            {
                sb.AppendFormat(item.ConsultarDatos(), "\n");

            }

            return sb.ToString();
        }
        public static bool operator ==(Estacionamiento esta, Vehiculo vei)
        {
            bool retorno = false;

            foreach (Vehiculo item in esta.vehiculos)
            {
                if (item == vei)
                {
                    retorno = true;
                    break;
                }
            }

            return retorno;
        }
        public static bool operator !=(Estacionamiento esta, Vehiculo vei)
        {
            return !(esta == vei);
        }
        public static Estacionamiento operator +(Estacionamiento esta, Vehiculo vei)
        {
            int aux = esta.espacioDisponible;

            if (esta.vehiculos.Count < aux)
            {
                if (vei.Patente != null)
                {
                    if (esta != vei)
                    {
                        esta.vehiculos.Add(vei);
                    }
                }
            }

            return esta;
        }
        public static string operator -(Estacionamiento esta, Vehiculo vei)
        {
            StringBuilder sb = new StringBuilder();
            int aux = 0;

            foreach (Vehiculo item in esta.vehiculos)
            {
                if (item == vei)
                {
                    sb.AppendFormat(item.ImprimirTicket());
                    esta.vehiculos.Remove(item);
                    break;
                }
                else
                {
                    if (aux == 0)
                    {
                        sb.AppendFormat("El vehículo no es parte del estacionamiento.\n");
                        aux = 1;
                    }
                }
            }

            return sb.ToString();

        }
        #endregion
    }
}
