﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Automovil : Vehiculo
    {
        #region Atributo

        private ConsoleColor color;
        private static int valorHora;

        #endregion

        #region Constructores 
        static Automovil()
        {
            valorHora = 50;
        }
        public Automovil(string patente,ConsoleColor color):base(patente)
        {
            this.color = color;
        }
        public Automovil(string patente, ConsoleColor color,int valor) : this(patente,color)
        {
            valorHora = valor;
        }

        #endregion

        #region Metodos
        public override bool Equals(object obj)
        {
            bool retorno = false;

            if (obj is Automovil)
            {
                retorno = true;
            }

            return retorno;
        }
        public override string ConsultarDatos()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat($"{base.ImprimirTicket()}");
            sb.AppendFormat($"Color: {this.color}\nValor hora: {valorHora}\n\n");

            return sb.ToString();
        }
        public override string ImprimirTicket()
        {
            
            StringBuilder sb = new StringBuilder();

            TimeSpan aux = ingreso - DateTime.Now;

            sb.AppendFormat(this.ConsultarDatos());
            sb.AppendFormat($"Costo estadia: {(DateTime.Now - this.ingreso).Hours * valorHora}\n");

            return sb.ToString();
        }
        #endregion

    }
}
