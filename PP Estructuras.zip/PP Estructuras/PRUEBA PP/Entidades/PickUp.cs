﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class PickUp : Vehiculo
    {
        #region Atributo
        private string modelo;
        private static int valorHora;
        #endregion

        #region Constructores 
        static PickUp()
        {
            valorHora = 70;
        }
        public PickUp(string patente,string modelo):base(patente)
        {
            this.modelo = modelo;
        }
        public PickUp(string patente,string modelo,int valor):this(patente,modelo)
        {
            valorHora = valor;
        }
        #endregion

        #region Metodos
        public override bool Equals(object obj)
        {
            bool retorno = false;

            if (obj is PickUp)
            {
                retorno = true;
            }

            return retorno;
        }
        public override string ConsultarDatos()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat($"{base.ImprimirTicket()}");
            sb.AppendFormat($"Modelo: {this.modelo}\nValor hora: {valorHora}\n\n");

            return sb.ToString();
        }
        public override string ImprimirTicket()
        {
            StringBuilder sb = new StringBuilder();

            TimeSpan aux = ingreso - DateTime.Now;

            sb.AppendFormat(this.ConsultarDatos());
            sb.AppendFormat($"Costo estadia: {(DateTime.Now-this.ingreso).Hours*valorHora}\n");

            return sb.ToString();
        }

        #endregion

    }
}
