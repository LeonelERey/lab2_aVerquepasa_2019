﻿using System;
using System.Linq;
using System.Text;

namespace Entidades
{
    public abstract class Vehiculo
    {
        #region Atributos

        protected DateTime ingreso;
        private string patente;

        #endregion

        #region Constructores 
        public Vehiculo(string patente)
        {
            this.patente = patente;
            this.ingreso = DateTime.Now.AddHours(-3);
        }
        #endregion

        #region Propiedades

        public string Patente
        {
            set
            {
                if (value.Count() < 7 && value.Count() > 5)
                {
                    patente = value;
                }
            }
            get
            {
                return this.patente;
            }
        }

        #endregion

        #region Metodos
        public abstract string ConsultarDatos();
        public string ToString()
        {
            string retorno;

            retorno = string.Format("Patente: {0}", Patente);

            return retorno;
        }
        public virtual string ImprimirTicket()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat($"{ToString()}\nFecha y hora: {this.ingreso}\n");

            return sb.ToString();
        }

        #endregion

        #region Operadores

        public static bool operator ==(Vehiculo v1, Vehiculo v2)
        {
            bool retorno = false;
            bool auxV1PickUp = PickUp.Equals(v1, v2);
            bool auxV1Moto = Moto.Equals(v1, v2);
            bool auxV1Automovil = Automovil.Equals(v1, v2);

            if (auxV1Automovil == true)
            {
                if (v1.patente == v2.patente)
                {
                    retorno = true;
                }
            }
            else
            {
                if (auxV1Moto == true)
                {
                    if (v1.patente == v2.patente)
                    {
                        retorno = true;
                    }
                }
                else
                {
                    if (auxV1PickUp == true)
                    {
                        if (v1.patente == v2.patente)
                        {
                            retorno = true;
                        }
                    }
                }
            }

            return retorno;
        }
        public static bool operator !=(Vehiculo v1, Vehiculo v2)
        {
            return !(v1 == v2);
        }

        #endregion

    }
}
