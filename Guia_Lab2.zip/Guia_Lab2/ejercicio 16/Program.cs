﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ejercicio_16
{
    class Program
    {
        static void Main(string[] args)
        {
            alumno alum1 = new alumno();
            alumno alum2 = new alumno();
            alumno alum3 = new alumno();

            alum1.nombre = "Joaquin";
            alum1.apellido = "Mandingo";
            alum1.legajo =1589;
            alum1.Estudiar(6,4);
            alum1.CalcularFinal();
            Thread.Sleep(1000);
            alum2.nombre = "Leonel";
            alum2.apellido = "Rey";
            alum2.legajo =1010;
            alum2.Estudiar(10, 9);
            alum2.CalcularFinal();
            Thread.Sleep(1000);
            alum3.nombre = "Luquitas";
            alum3.apellido = "Elpepo";
            alum3.legajo =6969;
            alum3.Estudiar(2, 6);
            alum3.CalcularFinal();

            Console.WriteLine("{0}\n\n{1}\n\n{2}",alum1.Mostrar(),alum2.Mostrar(),alum3.Mostrar());

            Console.ReadKey();
        }   
    }
}
