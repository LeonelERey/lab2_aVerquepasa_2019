﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_16
{
    class alumno
    {
        private byte nota1;
        private byte nota2;
        private float notafinal;
        public string apellido;
        public int legajo;
        public string nombre;

        public void Estudiar(byte nota1, byte nota2)
        {
            this.nota1 = nota1;
            this.nota2 = nota2;
        }
        public void CalcularFinal()
        {
            Random ran = new Random();
            if(this.nota1 >= 4 && this.nota2 >= 4)
            {
                this.notafinal = ran.Next(1, 10);
            }
            else
            {
                this.notafinal = -1;
            }
        }
        public string Mostrar()
        {
            StringBuilder retorno = new StringBuilder();

            retorno.AppendFormat("Nombre:{0}\nApellido:{1}\nLejago:{2}\nNota 1:{3}\nNota 2:{4}",this.nombre,this.apellido,this.legajo,this.nota1,this.nota2);
            if(this.notafinal==-1)
            {
                retorno.AppendFormat("\nNota Final:alumno desaprobado");
            }
            else
            {
                retorno.AppendFormat("\nNota Final:{0}",this.notafinal);
            }
            
            return retorno.ToString();
        }
    }
}
