﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_4
{
    class Program
    {
        static int fin = 0;
        static int suma = 0;
        static void Main(string[] args)
        {
            for (int i = 1; fin < 4; i++)
            {
                suma = 0;
                for (int j = 1; j < i; j++)
                {
                    if (i % j == 0)
                    {
                        suma += j;
                    }

                    if (suma == i && suma != 1)
                    {
                        if (i - 1 == j)
                        {
                            Console.WriteLine("{0}", i);
                            fin += 1;
                        }
                    }
                }
            }
            Console.ReadKey();
        }
    }
}
