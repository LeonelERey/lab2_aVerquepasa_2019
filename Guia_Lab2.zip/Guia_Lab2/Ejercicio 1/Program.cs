﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_1
{
    class Program
    {
        static int num;
        static int max;
        static int min;
        static int acum;
        static int cont =0;
        static double prom;

        static void Main(string[] args)
        {   

            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("ingresar numero:");
                int.TryParse(Console.ReadLine(), out num);
                if(i==0)
                {
                    max = num;
                    min = num;
                }
                else
                {
                    if(max<num)
                    {
                        max = num;
                    }
                    else
                    {
                        if(min>num)
                        {
                            min = num;
                        }
                    }
                    
                }

                cont += num;
                acum += 1;
            }
            prom=cont/acum;
            Console.WriteLine("maximo:{0}\nminimo:{1}\npromedio:{2}",max,min,prom);
            Console.ReadKey();

        }
    }
}
