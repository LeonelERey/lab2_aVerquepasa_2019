﻿namespace Form_Ejercicio_31
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn = new System.Windows.Forms.Button();
            this.btnCaja1 = new System.Windows.Forms.Button();
            this.btnCaja2 = new System.Windows.Forms.Button();
            this.rchClientes = new System.Windows.Forms.RichTextBox();
            this.rchCaja1 = new System.Windows.Forms.RichTextBox();
            this.rchCaja2 = new System.Windows.Forms.RichTextBox();
            this.rchClientAtendidos = new System.Windows.Forms.RichTextBox();
            this.lblClientes = new System.Windows.Forms.Label();
            this.lblCaja1 = new System.Windows.Forms.Label();
            this.lblCaja2 = new System.Windows.Forms.Label();
            this.lblClientAtendidos = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn
            // 
            this.btn.Location = new System.Drawing.Point(58, 12);
            this.btn.Name = "btn";
            this.btn.Size = new System.Drawing.Size(75, 23);
            this.btn.TabIndex = 0;
            this.btn.Text = "Registrar";
            this.btn.UseVisualStyleBackColor = true;
            this.btn.Click += new System.EventHandler(this.btn_Click);
            // 
            // btnCaja1
            // 
            this.btnCaja1.Location = new System.Drawing.Point(253, 260);
            this.btnCaja1.Name = "btnCaja1";
            this.btnCaja1.Size = new System.Drawing.Size(75, 23);
            this.btnCaja1.TabIndex = 1;
            this.btnCaja1.Text = "Atender";
            this.btnCaja1.UseVisualStyleBackColor = true;
            // 
            // btnCaja2
            // 
            this.btnCaja2.Location = new System.Drawing.Point(423, 260);
            this.btnCaja2.Name = "btnCaja2";
            this.btnCaja2.Size = new System.Drawing.Size(75, 23);
            this.btnCaja2.TabIndex = 2;
            this.btnCaja2.Text = "Atender";
            this.btnCaja2.UseVisualStyleBackColor = true;
            // 
            // rchClientes
            // 
            this.rchClientes.Location = new System.Drawing.Point(12, 60);
            this.rchClientes.Name = "rchClientes";
            this.rchClientes.Size = new System.Drawing.Size(170, 250);
            this.rchClientes.TabIndex = 3;
            this.rchClientes.Text = "";
            this.rchClientes.TextChanged += new System.EventHandler(this.rchClientes_TextChanged);
            // 
            // rchCaja1
            // 
            this.rchCaja1.Location = new System.Drawing.Point(209, 31);
            this.rchCaja1.Name = "rchCaja1";
            this.rchCaja1.Size = new System.Drawing.Size(159, 223);
            this.rchCaja1.TabIndex = 4;
            this.rchCaja1.Text = "";
            // 
            // rchCaja2
            // 
            this.rchCaja2.Location = new System.Drawing.Point(386, 31);
            this.rchCaja2.Name = "rchCaja2";
            this.rchCaja2.Size = new System.Drawing.Size(159, 223);
            this.rchCaja2.TabIndex = 5;
            this.rchCaja2.Text = "";
            // 
            // rchClientAtendidos
            // 
            this.rchClientAtendidos.Location = new System.Drawing.Point(578, 31);
            this.rchClientAtendidos.Name = "rchClientAtendidos";
            this.rchClientAtendidos.Size = new System.Drawing.Size(174, 279);
            this.rchClientAtendidos.TabIndex = 6;
            this.rchClientAtendidos.Text = "";
            // 
            // lblClientes
            // 
            this.lblClientes.AutoSize = true;
            this.lblClientes.Location = new System.Drawing.Point(73, 44);
            this.lblClientes.Name = "lblClientes";
            this.lblClientes.Size = new System.Drawing.Size(44, 13);
            this.lblClientes.TabIndex = 7;
            this.lblClientes.Text = "Clientes";
            // 
            // lblCaja1
            // 
            this.lblCaja1.AutoSize = true;
            this.lblCaja1.Location = new System.Drawing.Point(273, 15);
            this.lblCaja1.Name = "lblCaja1";
            this.lblCaja1.Size = new System.Drawing.Size(34, 13);
            this.lblCaja1.TabIndex = 8;
            this.lblCaja1.Text = "Caja1";
            // 
            // lblCaja2
            // 
            this.lblCaja2.AutoSize = true;
            this.lblCaja2.Location = new System.Drawing.Point(443, 15);
            this.lblCaja2.Name = "lblCaja2";
            this.lblCaja2.Size = new System.Drawing.Size(34, 13);
            this.lblCaja2.TabIndex = 9;
            this.lblCaja2.Text = "Caja2";
            // 
            // lblClientAtendidos
            // 
            this.lblClientAtendidos.AutoSize = true;
            this.lblClientAtendidos.Location = new System.Drawing.Point(623, 17);
            this.lblClientAtendidos.Name = "lblClientAtendidos";
            this.lblClientAtendidos.Size = new System.Drawing.Size(94, 13);
            this.lblClientAtendidos.TabIndex = 10;
            this.lblClientAtendidos.Text = "Clientes Atendidos";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Form_Ejercicio_31.Properties.Resources.Nuevo2;
            this.ClientSize = new System.Drawing.Size(764, 322);
            this.Controls.Add(this.lblClientAtendidos);
            this.Controls.Add(this.lblCaja2);
            this.Controls.Add(this.lblCaja1);
            this.Controls.Add(this.lblClientes);
            this.Controls.Add(this.rchClientAtendidos);
            this.Controls.Add(this.rchCaja2);
            this.Controls.Add(this.rchCaja1);
            this.Controls.Add(this.rchClientes);
            this.Controls.Add(this.btnCaja2);
            this.Controls.Add(this.btnCaja1);
            this.Controls.Add(this.btn);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Banco ejercicio 31";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn;
        private System.Windows.Forms.Button btnCaja1;
        private System.Windows.Forms.Button btnCaja2;
        private System.Windows.Forms.RichTextBox rchClientes;
        private System.Windows.Forms.RichTextBox rchCaja1;
        private System.Windows.Forms.RichTextBox rchCaja2;
        private System.Windows.Forms.RichTextBox rchClientAtendidos;
        private System.Windows.Forms.Label lblClientes;
        private System.Windows.Forms.Label lblCaja1;
        private System.Windows.Forms.Label lblCaja2;
        private System.Windows.Forms.Label lblClientAtendidos;
    }
}

