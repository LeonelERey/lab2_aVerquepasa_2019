﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ejercicio_31;
using Form_Ejercicio_31;

namespace Form_Ejercicio_31
{
    public partial class FormAgredar : Form
    {
        public FormAgredar()
        {
            InitializeComponent();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            string nombre = "pepe";
            Form1 nuevo = new Form1();
            nuevo=Form1.ActiveForm();
            
            this.Close();
        }
    }
}
