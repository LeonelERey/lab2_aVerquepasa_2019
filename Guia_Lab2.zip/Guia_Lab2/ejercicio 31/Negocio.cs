﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_31
{
    public class Negocio
    {
        private PuestoAtencion caja;
        private Queue<Cliente> clientes;
        private string nombre;

        public Cliente Clientes 
        {
            get
            {
                return clientes.Dequeue();
            }
            set
            {
                bool aux;
                aux = this + value;      
            }
        }
        private Negocio()
        {
            this.clientes = new Queue<Cliente>();
            this.caja = new PuestoAtencion(PuestoAtencion.Puesto.Caja1);
        }
        public Negocio(string nombre):this()
        {
            this.nombre = nombre;
        }

        public static bool operator ~(Negocio n)
        {
            bool returno = false;

            if(true==n.caja.atender(n.Clientes))
            {
                returno = true;
            }
            return returno;
        }
        public static bool operator +(Negocio n,Cliente c)
        {
            bool aux = false;
            
            foreach (Cliente item in n.clientes)
            {
                if (item == c)
                {
                    aux = true;
                    break;
                }
            }
            if(aux == false)
            {
                n.Clientes = c;
                aux = true;
            }

            return aux;
        }
        public static bool operator ==(Negocio n, Cliente c)
        {
            bool retorno = false;
            
            if(n.Clientes==c)
            {
                retorno=true;
            }

            return retorno;
        }
        public static bool operator !=(Negocio n, Cliente c)
        {
            return !(n == c);
        }
    }
}
