﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BoligrafoClase;

namespace ejercicio_17
{
    class Program
    {
        static void Main(string[] args)
        {

            Boligrafo bol1 = new Boligrafo(100,ConsoleColor.Blue);
            Boligrafo bol2 = new Boligrafo(50, ConsoleColor.Red);
            string dibujo;
            bool respuesta;

            respuesta=bol1.Pintar(25,out dibujo);
            Console.ForegroundColor = bol1.GetColor();
            Console.WriteLine(dibujo);
            if(respuesta == true)
            {
                Console.Write("Se pudo realizar el dibujo\n");
            }
            else
            {
                Console.Write("El dibujo no puedo ser realizado correctamente\n");
            }
            respuesta=bol2.Pintar(55, out dibujo);
            Console.ForegroundColor = bol2.GetColor();
            Console.WriteLine(dibujo);
            if (respuesta == true)
            {
                Console.Write("Se pudo realizar el dibujo\n");
            }
            else
            {
                Console.Write("El dibujo no puedo ser realizado correctamente\n");
            }

            Console.ReadKey();
        }
    }
}
