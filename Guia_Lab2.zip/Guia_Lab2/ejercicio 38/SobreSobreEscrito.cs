﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_38
{
    public class SobreSobreEscrito:SobreEscrito
    {
        public SobreSobreEscrito():base()
        {

        }

        public override string MiPropiedad
        {
            get
            {
                return base.miAtibuto;
            }
        }

        public override string MiMetodo()
        {
            return miAtibuto;
        }
    }
}
