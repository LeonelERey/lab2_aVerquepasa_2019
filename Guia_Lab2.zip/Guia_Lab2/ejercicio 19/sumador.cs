﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_19
{
    class Sumador
    {

        private int cantidadSuma;

        public Sumador(int cantidadSuma)
        {
            this.cantidadSuma = cantidadSuma;
        }
        public Sumador():this(0)
        {

        }
        public long Sumar (long num1, long num2)
        {
            long retorno;
            this.cantidadSuma += 1;
            retorno=num1 + num2;

            return retorno;
        }
        public string Sumar(string s1,string s2)
        {
            this.cantidadSuma += 1;
            return string.Concat(s1,s2);
        }
        public static long operator +(Sumador s1,Sumador s2)
        {
            long retorno;
            retorno=s1.cantidadSuma + s2.cantidadSuma;

            return retorno;
        }
    }
}
