﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_20
{
    public class Euro
    {
        private double cantidad;
        private static float cotizRespectoDolar;

        private Euro()
        {
            this.cantidad = 0;
            cotizRespectoDolar = (float)1.16;
        }
        public Euro(double cantidad) : this()
        {
            this.cantidad = cantidad;
        }
        public Euro(double cantidad, float cotizacion) : this(cantidad)
        {
            cotizRespectoDolar = cotizacion;
        }
        public double GetCantidad()
        {
            return this.cantidad;
        }
        public static double GetCotizacion()
        {
            return cotizRespectoDolar;
        }
        public static explicit operator Dolar(Euro e)
        {
            Dolar d = new Dolar(e.cantidad * Dolar.GetCotizacion());

            return d;
        }
        public static explicit operator Pesos(Euro e)
        {
            Pesos p = new Pesos(e.cantidad * Pesos.GetCotizacion());

            return p;
        }
        public static implicit operator Euro(double d)
        {
            Euro e = new Euro(d);

            return e;
        }
        public static Pesos operator +(Euro e, Dolar d)
        {
            return e.cantidad + ((Euro)d).GetCantidad();
        }

        public static Pesos operator +(Euro e, Pesos p)
        {
            return e.cantidad + ((Euro)p).GetCantidad();
        }
        public static Pesos operator -(Euro e, Pesos p)
        {
            return e.cantidad - ((Euro)p).GetCantidad();
        }
        public static Pesos operator -(Euro e , Dolar d)
        {
            return e.cantidad - ((Euro)e).GetCantidad();
        }
        public static bool operator ==(Euro e, Dolar d)
        {
            bool retorno = false;

            if (e.cantidad == ((Euro)d).GetCantidad())
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator !=(Euro e , Dolar d)
        {
            return !(d == e);
        }
        public static bool operator ==(Euro e, Pesos p)
        {
            bool retorno = false;

            if (e.cantidad == ((Euro)p).GetCantidad())
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator !=(Euro e, Pesos p)
        {
            return !(e == p);
        }
        public static bool operator ==(Euro e1, Euro e2)
        {
            bool retorno = false;

            if (e1.GetCantidad() == e2.GetCantidad())
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator !=(Euro e1, Euro e2)
        {
            return !(e1 == e2);
        }
    }
}
