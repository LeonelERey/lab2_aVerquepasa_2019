﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_20
{
    public class Pesos
    {
        private double cantidad;
        private static float cotizRespectoDolar;

        private Pesos()
        {
            this.cantidad = 0;
            cotizRespectoDolar = (float)38.33;


        }
        public Pesos(double cantidad):this()
        {
            this.cantidad = cantidad;
        }
        public Pesos(double cantidad,float cotizacion):this(cantidad)
        {
            cotizRespectoDolar = cotizacion;
        }
        public double GetCantidad()
        {
            return this.cantidad;
        }
        public static double GetCotizacion()
        {
            return cotizRespectoDolar;
        }
        public static explicit operator Dolar(Pesos p)
        {
            Dolar d = new Dolar(p.cantidad * Dolar.GetCotizacion());

            return d;
        }
        public static explicit operator Euro(Pesos p)
        {
            Euro e = new Euro(p.cantidad * Euro.GetCotizacion());

            return e;
        }
        public static implicit operator Pesos(double d)
        {
            Pesos p = new Pesos(d);

            return p;
        }
        public static Pesos operator +(Pesos p,Dolar d)
        {
            return p.cantidad + ((Pesos)d).GetCantidad();
        }

        public static Pesos operator +(Pesos p, Euro e)
        {
            return p.cantidad + ((Pesos)e).GetCantidad();
        }
        public static Pesos operator -(Pesos p, Dolar d)
        {
            return p.cantidad - ((Pesos)d).GetCantidad();
        }
        public static Pesos operator -(Pesos p, Euro e)
        {
            return p.cantidad - ((Pesos)e).GetCantidad();
        }
        public static bool operator ==(Pesos p, Euro e)
        {
            bool retorno = false;

            if(p.cantidad == ((Pesos)e).GetCantidad())
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator !=(Pesos p, Euro e)
        {
            return !(p == e);
        }
        public static bool operator ==(Pesos p, Dolar d)
        {
            bool retorno = false;

            if (p.cantidad == ((Pesos)d).GetCantidad())
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator !=(Pesos p, Dolar d)
        {
            return !(p == d);
        }
        public static bool operator ==(Pesos p1, Pesos p2)
        {
            bool retorno = false;

            if (p1.cantidad == ((Pesos)p2).GetCantidad())
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator !=(Pesos p1, Pesos p2)
        {
            return !(p1 == p2);
        }
    }
}
