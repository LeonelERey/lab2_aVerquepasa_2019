﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntidadesGuia;

namespace ejercicio_20
{
    public class Dolar
    {
        private double cantidad;
        private static float cotizRespectoDolar;

        private Dolar()
        {
            this.cantidad = 0;
            cotizRespectoDolar = 1;
        }
        public Dolar(double cantidad) : this()
        {
            this.cantidad = cantidad;
        }
        public Dolar(double cantidad, float cotizacion) : this(cantidad)
        {
            cotizRespectoDolar = cotizacion;
        }
        public double GetCantidad()
        {
            return this.cantidad;
        }
        public static double GetCotizacion()
        {
            return cotizRespectoDolar;
        }
        public static explicit operator Pesos(Dolar d)
        {
            Pesos p = new Pesos(d.cantidad * Pesos.GetCotizacion());

            return p;
        }
        public static explicit operator Euro(Dolar d)
        {
            Euro e = new Euro(d.cantidad * Euro.GetCotizacion());

            return e;
        }
        public static implicit operator Dolar(double d)
        {
            Dolar dol = new Dolar(d);

            return dol;
        }
        public static Pesos operator +(Dolar d, Euro e)
        {
            return d.cantidad + ((Dolar)e).GetCantidad();
        }

        public static Pesos operator +(Dolar d, Pesos p)
        {
            return d.cantidad + ((Dolar)p).GetCantidad();
        }
        public static Pesos operator -(Dolar d,Pesos p)
        {
            return d.cantidad - ((Dolar)p).GetCantidad();
        }
        public static Pesos operator -(Dolar d, Euro e)
        {
            return d.cantidad - ((Dolar)e).GetCantidad();
        }
        public static bool operator ==(Dolar d, Euro e)
        {
            bool retorno = false;

            if (d.cantidad == ((Dolar)e).GetCantidad())
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator !=(Dolar d, Euro e)
        {
            return !(d == e);
        }
        public static bool operator ==(Dolar d,Pesos p)
        {
            bool retorno = false;

            if (d.cantidad == ((Dolar)p).GetCantidad())
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator !=(Dolar d,Pesos p)
        {
            return !(d == p);
        }
        public static bool operator ==(Dolar d1, Dolar d2)
        {
            bool retorno = false;

            if (d1.GetCantidad() == d2.GetCantidad())
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator !=(Dolar d1, Dolar d2)
        {
            return !(d1 == d2);
        }
    
}
}
