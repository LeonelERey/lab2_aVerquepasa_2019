﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ejercicio_20;

namespace ejercicio_23_Entidades
{
    public class Moneda
    {

    }
}
