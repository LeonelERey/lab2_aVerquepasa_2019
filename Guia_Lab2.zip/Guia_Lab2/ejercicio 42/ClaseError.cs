﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_42
{
    public class ClaseError
    {
        #region METODO ESTATICO ªAª
        /*public static double dividir()
        {
            double retorno=0;

            try
            {                
                if(retorno==0)
                {
                    throw new DivideByZeroException("es cero.\n");
                }
            }
            catch(Exception)
            {

            }

            return retorno;
        }*/
        public static void MetodoEstatico()
        {
            try
            {
                int aux = 0;
                int resp = 10 / aux;
            }
            catch (DivideByZeroException c)
            {
                throw c;
            }
        }
        #endregion

        #region CONSTRUCTOR INSTANCIA ªBª 1/2
        public ClaseError()
        {
            try
            {
                ClaseError.MetodoEstatico();
            }
            catch (DivideByZeroException c)
            {
                throw c;
            }
        } 
        #endregion
    }
}
