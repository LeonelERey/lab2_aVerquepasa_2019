﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_42
{
    public class ClaseDoble
    {
        public ClaseDoble()
        {
            try
            {
                new ClaseError();
            }
            catch(DivideByZeroException c)
            {
                //throw new ;
            }
        }
    }
}
