﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_3
{
    class Program
    {
        static int num;
        static int acum;
        static void Main(string[] args)
        {
            Console.WriteLine("ingrese un numero:");
            int.TryParse(Console.ReadLine(), out num);

            for (int i = 1; i < num+1; i++)
            {
                acum = 0;
                for (int j = 1; j < i+1; j++)
                {
                    if (i % j == 0)
                    {
                        acum += 1;
                    }
                    if(j==i&&acum==2)
                    {
                        Console.WriteLine("{0}", i);
                    }                     
                }
            }
            Console.ReadKey();
        }
    }
}
