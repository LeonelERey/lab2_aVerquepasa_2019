﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_2
{
    class Program
    {
        static double num;
        static double numCuadrado;
        static double numCubo;

        static void Main(string[] args)
        {
            Console.WriteLine("ingresar numero:");
            double.TryParse(Console.ReadLine(), out num);
            while (num == 0)
            {
                Console.WriteLine("ERROR. ¡Reingresar número!");
                double.TryParse(Console.ReadLine(), out num);
            }
            numCuadrado = Math.Pow(num, 2);
            numCubo = Math.Pow(num, 3);

            Console.WriteLine("cuadrado:{0}\ncubo:{1}",numCuadrado,numCubo );
            Console.ReadKey();

        }
    }
}
